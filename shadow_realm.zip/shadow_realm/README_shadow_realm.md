# Shadow Realm

The code found within this folder is poorly documented, may be poorly written, buggy or simply made obsolete by better methods. Here you will find specters of the past and skeletons that are best kept hidden. There is a litany of past and alternate versions, incomplete implementations, old tests, standalone versions, etc.

Code that is no longer useful should be banished to the `shadow_realm` rather than permanently removed from play. This not only ensures future generations avoid the mistakes of the past, but on rare occasions may provide solutions to future problems.
