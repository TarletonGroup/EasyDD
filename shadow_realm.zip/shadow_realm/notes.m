% dis = [  1 ,  2  ,  3,     4,     5,      6,    7,  8,   9   ]
% dis = [xdis, ydis, type, dipole, alpha, plane,  s,  v,  grain]

% source = [  1 ,       2  ,  3,       4,         5 ,          6,          7    , 8,   9  ]
% source = [xSource,ySource, tn , nucleating, alphaSource, planeSource,  sSource, ~, grain]
