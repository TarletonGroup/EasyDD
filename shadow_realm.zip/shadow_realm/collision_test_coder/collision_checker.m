function [colliding_segments,n1s1,n2s1,n1s2,n2s2]=collision_checker(rn,links,connectivity,mindist)
% this subroutine goes through the existing links and checks for collisions
% it first checks through unconnected links
% it then checks for hinges that are coming within the mininum distance
mindist2=mindist*mindist;
lrn2=length(rn(1,:));
lrn3=lrn2-1;
% eps is the error factor of the calculation
eps=1e-12;
% check for two links colliding
i=1;

colliding_segments=0;
n1s1=0;
n2s1=0;
n1s2=0;
n2s2=0;

while i<size(links,1)
    %ignore virtual segments - FF
    if rn(links(i,1),end)==67 || rn(links(i,2),end)==67
        i=i+1;
        continue;
    end
    j=i+1;
    while j<=size(links,1)
        n1s1=links(i,1);
        n2s1=links(i,2);
        n1s2=links(j,1);
        n2s2=links(j,2);
        %fprintf('n1s1=%f, n2s1=%f, n1s2=%f, n2s2=%f \n',n1s1,n2s1,n1s2,n2s2);
        if (n1s1~=n1s2)&&(n1s1~=n2s2)&&(n2s1~=n1s2)&&(n2s1~=n2s2)
            [dist2,ddist2dt,~,~]=mindistcalc(rn(n1s1,1:lrn3),rn(n2s1,1:lrn3),rn(n1s2,1:lrn3),rn(n2s2,1:lrn3));
            collision_condition_is_met=((dist2<mindist2)&(ddist2dt<-eps))|(dist2<eps);
            if collision_condition_is_met==1;
                colliding_segments=1;
                disp('Colliding segments... running collision.m');
                return;
            end
        end
    
        j=j+1;
    end
    i=i+1;
end
% check for a hinge condition
i=1;
while i<=length(rn(:,1))
    %ignore virtual nodes - FF
    if rn(i,end)==67
        i=i+1;
        continue;
    end
    j=1;
    while j<=connectivity(i,1)
        nodenoti=links(connectivity(i,2*j),3-connectivity(i,2*j+1));
        k=1;
        while k<=connectivity(i,1)
            linkid=connectivity(i,2*k);
            % if node is on the link do not check for collision
            if j~=k
                % identify the nodes on the link
                n1s1=links(linkid,1);
                n2s1=links(linkid,2);
                [dist2,ddist2dt,~,~]=mindistcalc(rn(n1s1,1:lrn3),rn(n2s1,1:lrn3),rn(nodenoti,1:lrn3),rn(nodenoti,1:lrn3));
                collision_condition_is_met=(dist2<mindist2)&(ddist2dt<-eps);
                if collision_condition_is_met==1;
                    colliding_segments=1;
                    disp('Colliding segments... running collision.m');
                    return;
                end
            end
            k=k+1;
        end
        j=j+1;
    end
    i=i+1;
end


function [dist2,ddist2dt,L1,L2]=mindistcalc(x0vx0,x1vx1,y0vy0,y1vy1)
% this function finds the minimum distance bewtween two line segments
% seg1=x0->x1 seg2=y0->y1
% dist2 = square of the minimum distance between the two points
% L1 = normalize position on seg1 that is closest to seg2
% L2 = normalized position on seg2 that is closest to seg1
% ddist2dt = time rate of change of the distance between L1 and L2
x0=x0vx0(1:3);
x1=x1vx1(1:3);
y0=y0vy0(1:3);
y1=y1vy1(1:3);
if length(x0vx0)==6
    vx0=x0vx0(4:6);
    vx1=x1vx1(4:6);
    vy0=y0vy0(4:6);
    vy1=y1vy1(4:6);
else
    vx1=zeros(1,3);
    vx0=zeros(1,3);
    vy1=zeros(1,3);
    vy0=zeros(1,3);
end

seg1=x1-x0;
seg2=y1-y0;
vseg1=vx1-vx0;
vseg2=vy1-vy0;

A=seg1*seg1';
B=2*seg1*(x0'-y0');
C=2*seg1*seg2';
D=2*seg2*(y0'-x0');
E=seg2*seg2';
%F=x0*x0'+y0*y0';
G=C*C-4*A*E;
eps=1e-12;
if A<eps % seg1 is just a point
    L1=0;
    if E<eps
        L2=0;
    else
        L2=-0.5*D/E;
    end
elseif E<eps % seg2 is just a point
    L2=0;
    if A<eps
        L1=0;
    else
        L1=-0.5*B/A;
    end
elseif abs(G)<eps % lines are parallel
    dist2=[(y0-x0)*(y0-x0)' (y1-x0)*(y1-x0)' (y0-x1)*(y0-x1)' (y1-x1)*(y1-x1)'];
    [~,pos]=min(dist2);
    L1=floor(pos/2);
    L2=mod(pos-1,2);
else
    L2=(2*A*D+B*C)/G;
    L1=0.5*(C*L2-B)/A;
end

% now check to make sure that L2 and L1 are betwen 0 and 1
L1=min(max([L1,0]),1);
L2=min(max([L2,0]),1);

% now calculate the distance^2 and the time rate of change of the distance between the points at L1 and L2
dist2=(x0+seg1.*L1-y0-seg2.*L2)*(x0+seg1.*L1-y0-seg2.*L2)';
ddist2dt=2*((vx0+vseg1.*L1-vy0-vseg2.*L2)*(x0+seg1.*L1-y0-seg2.*L2)');